function start() {
    console.log('Периметр равен', storona.value*4);
}