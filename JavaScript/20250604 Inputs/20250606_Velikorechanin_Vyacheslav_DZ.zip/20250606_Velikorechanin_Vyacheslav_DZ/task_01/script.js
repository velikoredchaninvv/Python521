function start() {
    console.log('Привет',yma.value);
}