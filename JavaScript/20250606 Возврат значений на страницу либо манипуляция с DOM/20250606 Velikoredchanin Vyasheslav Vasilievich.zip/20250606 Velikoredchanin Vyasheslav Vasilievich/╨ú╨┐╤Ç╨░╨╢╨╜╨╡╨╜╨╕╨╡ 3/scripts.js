function start() {
    console.log('Площадь окружности равна: ', 3.14 * (radius.value * 2));
    
    // let data = document.createElement('data')

}
