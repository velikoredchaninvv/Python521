count = 10
while count > 0:
    count -= 2
